<?php
include("bg.php");

// Python'dan veya tarayıcıdan gelen ?time ve ?uid parametreleri
$time = isset($_GET['time']) ? (int)$_GET['time'] : 0;
$uid = isset($_GET['uid']) ? $_GET['uid'] : '';

if ($time > 0 && !empty($uid)) {
    // Python betiğini çalıştırma
    $escaped_time = escapeshellarg($time);
    $escaped_uid = escapeshellarg($uid);
    
    $command = "python3 countdwn.py $escaped_time $escaped_uid";

    // Komutu çalıştırma ve çıktıyı yakalama
    $descriptorspec = [
        0 => ["pipe", "r"],  // stdin
        1 => ["pipe", "w"],  // stdout
        2 => ["pipe", "w"]   // stderr
    ];

    $process = proc_open($command, $descriptorspec, $pipes);

    if (is_resource($process)) {
        // Komutu arka planda çalıştır
        proc_close($process);

        
    } else {

    }
} else {
    echo "Geçersiz zaman veya uid değeri.";
}
?>

