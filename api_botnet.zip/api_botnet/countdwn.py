import sys
import time
import mysql.connector

def countdown_and_update(time_seconds, uid):
    # Geri sayım
    time.sleep(time_seconds)
    
    # Veritabanı bağlantısı
    db = mysql.connector.connect(
        host="localhost",
        user="root",
        password="",
        database="kurban_attack"
    )
    
    cursor = db.cursor()
    
    # Veritabanını güncelleme
    query = "UPDATE attacks SET attack_status = 'finished' WHERE attack_uid = %s"
    cursor.execute(query, (uid,))
    db.commit()
    
    cursor.close()
    db.close()
    print(f"Geri sayım {time_seconds} saniye sürdü ve attack_uid {uid} ile güncellendi.")

if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Kullanım: python script.py <saniye> <uid>")
    else:
        try:
            time_seconds = int(sys.argv[1]) + 30
            uid = sys.argv[2]
            countdown_and_update(time_seconds, uid)
        except ValueError:
            print("Geçersiz zaman değeri. Lütfen bir sayı girin.")

