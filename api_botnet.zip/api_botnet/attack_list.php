<?php
include("bg.php");
try {
    // SQL sorgusu: attack_status 'running' olan en eski 5 satırı seç
    $sql = "SELECT id, target_ip, target_port, attack_type, attack_uid, attack_status, attacker_user, attack_time 
            FROM attacks 
            WHERE attack_status = 'running' 
            ORDER BY id ASC 
            LIMIT 100";
    $stmt = $conn->prepare($sql);
    $stmt->execute();

    // Sonuçları al
    $results = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Ayıklanabilir JSON formatına çevir
    $response = [
        'data' => $results
    ];
    $json_results = json_encode($response, JSON_PRETTY_PRINT);

    // JSON veriyi döndür
    header('Content-Type: application/json');
    echo $json_results;

} catch (PDOException $e) {
    // Hata mesajı
    echo 'Veritabanı bağlantı hatası: ' . $e->getMessage();
}
?>

