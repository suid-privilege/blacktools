<?php
error_reporting(1);
include("bg.php");

header('Content-Type: application/json');

try {
    // Aktif kullanıcıların sayısını al
    $sqlActive = "SELECT COUNT(*) as active_count FROM active_clients WHERE last_ping > (NOW() - INTERVAL 90 SECOND)";
    $stmtActive = $conn->query($sqlActive);
    $rowActive = $stmtActive->fetch(PDO::FETCH_ASSOC);
    $activeCount = $rowActive['active_count'];

    // Toplam kullanıcı sayısını al
    $sqlTotal = "SELECT COUNT(*) as total_count FROM active_clients";
    $stmtTotal = $conn->query($sqlTotal);
    $rowTotal = $stmtTotal->fetch(PDO::FETCH_ASSOC);
    $totalCount = $rowTotal['total_count'];

    // JSON çıktısı
    echo json_encode(['online' => $activeCount, 'total' => $totalCount]);
} catch(PDOException $e) {
    echo json_encode(['error' => 'Hata: ' . $e->getMessage()]);
}

$conn = null;
?>

