-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jul 20, 2024 at 05:33 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kurban_attack`
--

-- --------------------------------------------------------

--
-- Table structure for table `active_clients`
--

CREATE TABLE `active_clients` (
  `id` int(11) NOT NULL,
  `client_ip` varchar(45) DEFAULT NULL,
  `last_ping` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `active_clients`
--

INSERT INTO `active_clients` (`id`, `client_ip`, `last_ping`) VALUES
(8, '192.168.1.103', '2024-07-20 15:32:29'),
(11, '192.168.223.138', '2024-07-14 20:59:26'),
(12, '192.168.1.102', '2024-07-16 02:39:51');

-- --------------------------------------------------------

--
-- Table structure for table `attacks`
--

CREATE TABLE `attacks` (
  `id` int(11) NOT NULL,
  `target_ip` text NOT NULL,
  `target_port` text NOT NULL,
  `attack_type` text NOT NULL,
  `attack_time` text NOT NULL,
  `attack_uid` text NOT NULL,
  `attack_status` text NOT NULL,
  `attacker_user` text NOT NULL,
  `use_bot` text NOT NULL,
  `start_time` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `active_clients`
--
ALTER TABLE `active_clients`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `client_ip` (`client_ip`);

--
-- Indexes for table `attacks`
--
ALTER TABLE `attacks`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `active_clients`
--
ALTER TABLE `active_clients`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `attacks`
--
ALTER TABLE `attacks`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=47;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
