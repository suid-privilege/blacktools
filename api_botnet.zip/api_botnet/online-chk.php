<?php
error_reporting(1);
include("bg.php");
$expectedUserAgent = "mozdotnet";

try {
    // User-Agent kontrolü
    if ($_SERVER['HTTP_USER_AGENT'] !== $expectedUserAgent) {
        echo "Geçersiz User-Agent.";
        exit;
    }

    $client_ip = $_SERVER['REMOTE_ADDR'];

    // Veritabanına bağlantı kurulduğundan emin olun
    if (!$conn) {
        echo "Veritabanı bağlantısı başarısız.";
        exit;
    }

    // IP adresi mevcutsa `last_ping` tarihini güncelle
    $sql = "UPDATE active_clients SET last_ping = CURRENT_TIMESTAMP WHERE client_ip = :client_ip";

    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':client_ip', $client_ip);
    $stmt->execute();

    // Eğer IP adresi yoksa yeni bir kayıt ekleyin
    if ($stmt->rowCount() === 0) {
        $sqlInsert = "INSERT INTO active_clients (client_ip, last_ping) VALUES (:client_ip, CURRENT_TIMESTAMP)";
        $stmtInsert = $conn->prepare($sqlInsert);
        $stmtInsert->bindParam(':client_ip', $client_ip);
        $stmtInsert->execute();
    }

    echo "Ping başarılı.";
} catch(PDOException $e) {
    echo "Ping başarısız: " . $e->getMessage();
}

$conn = null;
?>

