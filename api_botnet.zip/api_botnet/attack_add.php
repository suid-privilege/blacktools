<?php
include("bg.php");
date_default_timezone_set('Europe/Istanbul'); // Uygun zaman dilimini ayarlayın

try {
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Base64 decode input from POST
    $target_ip = base64_decode($_POST['target_ip']);
    $target_port = base64_decode($_POST['target_port']);
    $attack_type = base64_decode($_POST['attack_type']);
    $attack_time = base64_decode($_POST['attack_time']);
    $attack_uid = base64_decode($_POST['attack_uid']);
    $attack_status = base64_decode($_POST['attack_status']);
    $attacker_user = base64_decode($_POST['attacker_user']);
    $use_bot = base64_decode($_POST['use_bot']);
    $now = new DateTime();  
    $current_time = $now->format('Y-m-d H:i:s');
    $now->modify('+1 minute');
    $time_after_one_minute = $now->format('Y-m-d H:i:s');
    $time_today = $time_after_one_minute;

    $sql = "INSERT INTO attacks (target_ip, target_port, attack_type, attack_time, attack_uid, attack_status, attacker_user, use_bot, start_time) 
            VALUES (:target_ip, :target_port, :attack_type, :attack_time, :attack_uid, :attack_status, :attacker_user, :use_bot, :start_time)";

    $stmt = $conn->prepare($sql);

    $stmt->bindParam(':target_ip', $target_ip);
    $stmt->bindParam(':target_port', $target_port);
    $stmt->bindParam(':attack_type', $attack_type);
    $stmt->bindParam(':attack_time', $attack_time);
    $stmt->bindParam(':attack_uid', $attack_uid);
    $stmt->bindParam(':attack_status', $attack_status);
    $stmt->bindParam(':attacker_user', $attacker_user);
    $stmt->bindParam(':use_bot', $use_bot);
    $stmt->bindParam(':start_time', $time_today);
    $stmt->execute();

    echo "Veri başarıyla eklendi.";

} catch (PDOException $e) {
    echo "Veri eklenirken hata oluştu: " . $e->getMessage();
}
?>

