<?php
include("bg.php");

try {


    // Son 10 dakikada ping almayan kayıtları silme
    $sql = "DELETE FROM active_clients WHERE last_ping < (NOW() - INTERVAL 2 MINUTE)";
    $stmt = $conn->prepare($sql);
    $stmt->execute();

    echo "Eski kayıtlar temizlendi.";
} catch(PDOException $e) {
    echo "Temizleme hatası: " . $e->getMessage();
}

$conn = null;
?>

