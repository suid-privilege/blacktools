<?php
include("bg.php");
date_default_timezone_set('Europe/Istanbul'); // Uygun zaman dilimini ayarlayın
try {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // POST ile gelen veriyi al
        $attacker_user = $_POST['attacker_user'];
        if(isset($_POST['allof']))
        {
                    $sql = "SELECT id, target_ip, target_port, attack_type, attack_status, attacker_user, attack_time, use_bot, start_time 
                FROM attacks 
                WHERE attacker_user = :attacker_user
                ORDER BY id ASC 
                LIMIT 100";
        }
        else {
        
                    $sql = "SELECT id, target_ip, target_port, attack_type, attack_status, attacker_user, attack_time, use_bot, start_time 
                FROM attacks 
                WHERE attack_status = 'running' AND attacker_user = :attacker_user
                ORDER BY id ASC 
                LIMIT 100";        
        
        }
        // SQL sorgusu: Belirtilen attacker_user için attack_status 'running' olan en eski 5 satırı seç

        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':attacker_user', $attacker_user, PDO::PARAM_STR);
        $stmt->execute();

        // Sonuçları al
        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Kalan zamanı hesapla
        $currentTime = time();
        foreach ($results as &$result) {
            $startTime = strtotime($result['start_time']);
            if ($startTime !== false) {
                $elapsedTime = $currentTime - $startTime;
                $result['remaining_time'] = max((int)$result['attack_time'] - $elapsedTime, 0);

            } else {
                $result['remaining_time'] = 0; // Hata durumunda kalan zamanı sıfır yap
            }
        }

        // Ayıklanabilir JSON formatına çevir
        $response = [
            'data' => $results
        ];
        $json_results = json_encode($response, JSON_PRETTY_PRINT);

        // JSON veriyi döndür
        header('Content-Type: application/json');
        echo $json_results;
    } else {
        // Geçersiz istek yöntemi
        echo json_encode(['error' => 'Invalid request method. Please use POST.']);
    }
} catch (PDOException $e) {
    // Hata mesajı
    echo json_encode(['error' => 'Veritabanı bağlantı hatası: ' . $e->getMessage()]);
}
?>

